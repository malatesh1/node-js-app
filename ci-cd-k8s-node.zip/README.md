
# CI/CD Project (Node.js + Jenkins + K8s + Prometheus + Grafana)

## 🚀 Features
- Node.js Express App
- Dockerized
- Jenkins CI/CD pipeline
- Kubernetes deployment (Minikube)
- Monitoring with Prometheus & Grafana

## 🧪 Steps to Run
1. Clone repo and set up DockerHub repo
2. Start Jenkins and configure pipeline
3. Run `minikube start`
4. Deploy using Jenkins
5. Install Prometheus & Grafana:
   - `kubectl apply -f monitoring/`
6. View metrics in Grafana

## 🔧 Ports
- App: `NodePort 30080`
- Grafana: `NodePort 30000` (if exposed)
